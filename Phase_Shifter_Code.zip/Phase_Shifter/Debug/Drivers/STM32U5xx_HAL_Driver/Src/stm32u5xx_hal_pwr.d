Drivers/STM32U5xx_HAL_Driver/Src/stm32u5xx_hal_pwr.o: \
 ../Drivers/STM32U5xx_HAL_Driver/Src/stm32u5xx_hal_pwr.c \
 ../Drivers/STM32U5xx_HAL_Driver/Inc/stm32u5xx_hal.h \
 ../Core/Inc/stm32u5xx_hal_conf.h \
 ../Drivers/STM32U5xx_HAL_Driver/Inc/stm32u5xx_hal_rcc.h \
 ../Drivers/STM32U5xx_HAL_Driver/Inc/stm32u5xx_hal_def.h \
 ../Drivers/CMSIS/Device/ST/STM32U5xx/Include/stm32u5xx.h \
 ../Drivers/CMSIS/Device/ST/STM32U5xx/Include/stm32u575xx.h \
 ../Drivers/CMSIS/Include/core_cm33.h \
 ../Drivers/CMSIS/Include/cmsis_version.h \
 ../Drivers/CMSIS/Include/cmsis_compiler.h \
 ../Drivers/CMSIS/Include/cmsis_gcc.h \
 ../Drivers/CMSIS/Include/mpu_armv8.h \
 ../Drivers/CMSIS/Device/ST/STM32U5xx/Include/system_stm32u5xx.h \
 ../Drivers/STM32U5xx_HAL_Driver/Inc/Legacy/stm32_hal_legacy.h \
 ../Drivers/STM32U5xx_HAL_Driver/Inc/stm32u5xx_hal_rcc_ex.h \
 ../Drivers/STM32U5xx_HAL_Driver/Inc/stm32u5xx_hal_gpio.h \
 ../Drivers/STM32U5xx_HAL_Driver/Inc/stm32u5xx_hal_gpio_ex.h \
 ../Drivers/STM32U5xx_HAL_Driver/Inc/stm32u5xx_hal_icache.h \
 ../Drivers/STM32U5xx_HAL_Driver/Inc/stm32u5xx_hal_dma.h \
 ../Drivers/STM32U5xx_HAL_Driver/Inc/stm32u5xx_hal_dma_ex.h \
 ../Drivers/STM32U5xx_HAL_Driver/Inc/stm32u5xx_hal_cortex.h \
 ../Drivers/STM32U5xx_HAL_Driver/Inc/stm32u5xx_hal_flash.h \
 ../Drivers/STM32U5xx_HAL_Driver/Inc/stm32u5xx_hal_flash_ex.h \
 ../Drivers/STM32U5xx_HAL_Driver/Inc/stm32u5xx_hal_pwr.h \
 ../Drivers/STM32U5xx_HAL_Driver/Inc/stm32u5xx_hal_pwr_ex.h \
 ../Drivers/STM32U5xx_HAL_Driver/Inc/stm32u5xx_hal_spi.h \
 ../Drivers/STM32U5xx_HAL_Driver/Inc/stm32u5xx_hal_spi_ex.h \
 ../Drivers/STM32U5xx_HAL_Driver/Inc/stm32u5xx_hal_uart.h \
 ../Drivers/STM32U5xx_HAL_Driver/Inc/stm32u5xx_hal_uart_ex.h \
 ../Drivers/STM32U5xx_HAL_Driver/Inc/stm32u5xx_hal_exti.h
../Drivers/STM32U5xx_HAL_Driver/Inc/stm32u5xx_hal.h:
../Core/Inc/stm32u5xx_hal_conf.h:
../Drivers/STM32U5xx_HAL_Driver/Inc/stm32u5xx_hal_rcc.h:
../Drivers/STM32U5xx_HAL_Driver/Inc/stm32u5xx_hal_def.h:
../Drivers/CMSIS/Device/ST/STM32U5xx/Include/stm32u5xx.h:
../Drivers/CMSIS/Device/ST/STM32U5xx/Include/stm32u575xx.h:
../Drivers/CMSIS/Include/core_cm33.h:
../Drivers/CMSIS/Include/cmsis_version.h:
../Drivers/CMSIS/Include/cmsis_compiler.h:
../Drivers/CMSIS/Include/cmsis_gcc.h:
../Drivers/CMSIS/Include/mpu_armv8.h:
../Drivers/CMSIS/Device/ST/STM32U5xx/Include/system_stm32u5xx.h:
../Drivers/STM32U5xx_HAL_Driver/Inc/Legacy/stm32_hal_legacy.h:
../Drivers/STM32U5xx_HAL_Driver/Inc/stm32u5xx_hal_rcc_ex.h:
../Drivers/STM32U5xx_HAL_Driver/Inc/stm32u5xx_hal_gpio.h:
../Drivers/STM32U5xx_HAL_Driver/Inc/stm32u5xx_hal_gpio_ex.h:
../Drivers/STM32U5xx_HAL_Driver/Inc/stm32u5xx_hal_icache.h:
../Drivers/STM32U5xx_HAL_Driver/Inc/stm32u5xx_hal_dma.h:
../Drivers/STM32U5xx_HAL_Driver/Inc/stm32u5xx_hal_dma_ex.h:
../Drivers/STM32U5xx_HAL_Driver/Inc/stm32u5xx_hal_cortex.h:
../Drivers/STM32U5xx_HAL_Driver/Inc/stm32u5xx_hal_flash.h:
../Drivers/STM32U5xx_HAL_Driver/Inc/stm32u5xx_hal_flash_ex.h:
../Drivers/STM32U5xx_HAL_Driver/Inc/stm32u5xx_hal_pwr.h:
../Drivers/STM32U5xx_HAL_Driver/Inc/stm32u5xx_hal_pwr_ex.h:
../Drivers/STM32U5xx_HAL_Driver/Inc/stm32u5xx_hal_spi.h:
../Drivers/STM32U5xx_HAL_Driver/Inc/stm32u5xx_hal_spi_ex.h:
../Drivers/STM32U5xx_HAL_Driver/Inc/stm32u5xx_hal_uart.h:
../Drivers/STM32U5xx_HAL_Driver/Inc/stm32u5xx_hal_uart_ex.h:
../Drivers/STM32U5xx_HAL_Driver/Inc/stm32u5xx_hal_exti.h:
